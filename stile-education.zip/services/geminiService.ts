import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getSystemInstruction = (gameTitle: string) => `
You are Gemini, a helpful and intelligent AI assistant.
The user is currently playing: "${gameTitle}".
Your goal is to help the user with anything they need, whether it's specific strategies for the game they are playing, homework help, or general conversation.

- Context: The user is likely at school or work, using this app which is disguised as an educational tool.
- Tone: Friendly, helpful, concise, and smart.
- Game Help: If asked about ${gameTitle}, provide specific tips (mechanics, controls, strategies).
- General Help: If asked about other topics (math, science, writing), provide excellent educational assistance.
`;

export const streamGameTips = async function* (
  history: { role: string; parts: { text: string }[] }[],
  newMessage: string,
  gameTitle: string
) {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: getSystemInstruction(gameTitle),
        thinkingConfig: { thinkingBudget: 0 }, // Disable thinking for faster chat response
      },
      history: history,
    });

    const result = await chat.sendMessageStream({ message: newMessage });

    for await (const chunk of result) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield "⚠️ Connection interference. Try again.";
  }
};